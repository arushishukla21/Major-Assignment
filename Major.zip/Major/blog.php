<html>
<head>
<?php
    include('connect.php');
?>

<title>MY MOVE | Blog</title>

<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="images/logo.png">

</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.html">MY MOVE<small> move with your style</small></a></h1>
      </div>
      <div class="menu_nav">
        <ul>
          <li><a href="index.html">Home </a></li>
          <li><a href="about.html">About Us </a></li>
          <li class="active"><a href="newBlog.php">Blog </a></li>
          <li><a href="newContact.php">Contact Us </a></li>
        </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="hbg">
    <div class="hbg_resize"><img src="images/d5.jpg" alt="" width="888" height="350" /></div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>A Blog</span> Entry</h2>
          <div class="clr"></div>
          <p>Posted by <a href="#">ArushiShukla</a> </p>
          <p> “We love dance,” the blog says. “And we know you do, too. Steezy’s mission is to share the dance experience by making it accessible to everyone.”

					matter your form of dance, I felt some of the posts really could apply to any type of dancer.<br>
				The blog celebrates “all aspects of dance and fitness through sharing knowledge, inspiration, tips, news and interviews,” the site says.
				</p>
          
          
        </div>
        <div class="article">
          <h2> Responses</h2>
          <div class="clr"></div>
          <div class="comment"> <a href="#"><img src="images/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
            <p><a>NICK JAMES </a> Says:<br />
              March 20th, 2019 at 2:17 pm</p>
            <p>“Nickelz Production provides a hub for dancers to come together to train on the fundamentals of dance, develop technically, grow as performers explore creativity and discover who they are as a dancer,” it says. “We are of the belief that when dancers with a common purpose to ‘Become Better Dancers’ train together, develop together, and explore together they automatically challenge and inspire each other to become better dancers.”

I love this site’s use of animated GIFs. Very amusing.</p>
          </div>
          <div class="comment"> <a href="#"><img src="images/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
            <p><a href="#">VANSHIKA SHUKLA </a> Says:<br />
              Feburary 1st, 2019 at 3:21 pm</p>
            <p>“The information provided here is designed to help you optimize your body’s biomechanics and provide the tools you need to empower you in your own healing,” the blog says.

The site was started by Lisa Howell, who in 2005 started Perfect Form Physio, one of the first physiotherapy clinics with a focus on the treatment and education of dancers.</p>
          </div>
          <div class="comment"> <a href="#"><img src="images/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
            <p><a href="#">SHUBHAM </a>Says:<br />
              January 15th, 2019 at 11:00 pm</p>
            <p>What an incredible article. As a ballet dance academy, I whole-heatedly believe that ballet needs to made a drastic change. I just created a website with a mission of to be recognized as a brand that is associated with high quality of technical training to all those who are passionate about ballet. – I’m hoping to connect with ballet dance lovers , and reveal some of the many things that the ballet world needs to change.</p>
          </div>
        </div>
        <div class="article">
          <h2><span>Leave a</span> Reply</h2>
          <div class="clr"></div>
          <form action="blog.php" name="register" onsubmit="return validateform()" >
            <ol>
              <li>
                
                <input id="name" placeholder="Full Name" name="fname" class="text" oninput="uppercase()" autofocus />
              </li>
              <li>
                
                <input id="email" placeholder="Email Address" name="email" class="text" />
              </li>
              
              <li>
               
                <textarea id="message" placeholder="Write your blog" name="message" rows="8" cols="50"></textarea>
              </li>
              <li>
                <input type="submit" name="submit" class="send" value="Submit">
				
				<script>
					
					function validateform()
					{
						var x=document.register.fname.value;
						var y=document.register.email.value;
						var z=document.register.message.value;
						
						if(x=='')
						{
							alert("Full name is required");
							return false;
						}
						
						else if(y=='')
						{
							alert("Your email is required");
							return false;
						}
						
						else if(z=='')
						{
						alert("You have not written any text");
							return false;
						}
						
						else
						{
							alert("Your blog is created.");
						}
				
					}
					
					function uppercase()
					{
						var x=document.register.fname.value;
						x=x.toUpperCase();
						document.register.fname.value=x;
					}
				</script>
				
				<?php
						
						if(isset($_POST['submit']))
						 {
							$fname=$_POST['fname'];
							$email=$_POST['email'];
							$message=$_POST['message'];
							
							//INSERT THE DATA INTO THE DATABASE
							$sql="INSERT INTO contact(fname,email,message) values('$fname','$email','$message')";
							if($conn->query($sql) === TRUE)
							{
								echo"<script>alert('NEW RECORD HAS BEEN ADDED SUCCESSFULLY')</script>";
							}
							else
							{
								echo"ERROR: ".$sql."<br>".$conn->error;
							}
						}
						
				?>
				
                <div class="clr"></div>
              </li>
            </ol>
          </form>
        </div>
      </div>
      
	  <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Social Connect</span></h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="https://www.facebook.com/" target="_blank" style="color:blue;" >FACEBOOK</a></li>
		<li><a href="https://twitter.com/login?lang=enhttps://twitter.com/login?lang=en" target="_blank" style="color:#85C1E9;">TWITTER</a></li>
		<li><a href="https://www.instagram.com/?hl=en" target="_blank" style="color:#D829A1;">INSTAGRAM</a></li>
		<li><a href="https://in.pinterest.com/" target="_blank" style="color:red;">PINTEREST</a></li>
           
          </ul>
        </div>
        <div class="gadget">
          <h2 class="star"><span>Our Sponsors</span></h2>
          <div class="clr"></div>
          <ul class="ex_menu">
		  
            <li><a href="http://www.ril.com/" target="_blank">RELIANCE INDUSTRIES</a><br /></li>
            <li><a href="https://www.oppo.com/in/"  target="_blank">OPPO MOBILES</a><br /></li>
            <li><a href="https://www.dabur.com/in/en-us/products/real"  target="_blank">REAL JUICE</a><br /></li>
            <li><a href="http://www.radiomirchi.com/" target="_blank">RADIO MIRCHI</a><br /></li>
            
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        
        <h2><span>New for 2019 !!</span></h2>
        <p><br />
          Advanced Level Studios may now have (2) routines per division! <br>
		  Example:  Advanced Junior – (2) Small Groups, (2) Large Groups & (2) Lines</p>
      </div>
      <div class="col c3">
        <h2><span>Registration opens June 10,2019</span></h2>
        
        <p>Spots are limited and will be filled on a first-come, first served basis.
			<br>
			Routines may only qualify at National Championships if there is space available in that division.
			</p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">Copyright @2019 All Rights Reserved</p>
      <p class="rf">Design by Arushi Shukla ITD-18030</a></p>
      <div class="clr"></div>
    </div>
  </div>
</div>
</body>
</html>
