<html>
<head>
<title>MY MOVE | Contact</title>

<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="images/logo.png">

</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.html">MY MOVE<small> move with your style</small></a></h1>
      </div>
      <div class="menu_nav">
        <ul>
          <li><a href="index.html">Home </a></li>
          <li><a href="about.html">About Us </a></li>
          <li><a href="newBlog.php">Blog </a></li>
          <li class="active"><a href="newContact.php">Contact Us </a></li>
        </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="hbg">
    
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Contact Us now </span></h2>
          <div class="clr"></div>
          <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d217994.6276812313!2d76.24300452416605!3d31.381984452145886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x877dbdb1cb07eab8!2sNritalya+Dance+Studio!5e0!3m2!1sen!2sin!4v1554846777245!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></p>
        </div>
        <div class="article">
          <h2><span>Send us</span> mail</h2>
          <div class="clr"></div>
          <form action="contact.php" method="post" name="register" onsubmit="return validateform()" >
            <ol>
              <li>
                <input id="name" placeholder="Full Name" name="fname" class="text" />
              </li>
              <li>
               
                <input id="email" placeholder="Email" name="email" class="text" />
              </li>
              
              <li>
                
                <textarea placeholder="Write your message" id="message" name="message" rows="8" cols="50"></textarea>
              </li>
			  <br>
              <li>
                <input type="submit" name="submit" value="Submit" href="mailto:mymove62@example.com">
				
				<?php

						if($_POST["submit"]) {
							$recipient="mymove62@gmail.com";
							$subject="Form to email message";
							$sender=$_POST["fname"];
							$senderEmail=$_POST["email"];
							$message=$_POST["message"];

							$mailBody="Name: $sender\nEmail: $senderEmail\n\n$message";

							mail($recipient, $subject, $mailBody, "From: $sender <$senderEmail>");

							$thankYou="<p>Thank you! Your message has been sent.</p>";
						}

				?>
				
				
				<script>
				
					
					function validateform()
					{
						var x=document.register.fname.value;
						var y=document.register.email.value;
						var z=document.register.message.value;
						
						if(x=='')
						{
							alert("Full name is required");
							return false;
						}
						
						else if(y=='')
						{
							alert("Your email is required");
							return false;
						}
						
						else if(z=='')
						{
						alert("You have not written any text");
							return false;
						}
						
						else
						{
							alert("Your message is sent.");
						}
				
					}
					
					function uppercase()
					{
						var x=document.register.fname.value;
						x=x.toUpperCase();
						document.register.fname.value=x;
					}
					
				</script>
                <div class="clr"></div>
              </li>
            </ol>
          </form>
        </div>
      </div>
     
	  <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Social Connect</span></h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="https://www.facebook.com/" target="_blank" style="color:blue;" >FACEBOOK</a></li>
		<li><a href="https://twitter.com/login?lang=enhttps://twitter.com/login?lang=en" target="_blank" style="color:#85C1E9;">TWITTER</a></li>
		<li><a href="https://www.instagram.com/?hl=en" target="_blank" style="color:#D829A1;">INSTAGRAM</a></li>
		<li><a href="https://in.pinterest.com/" target="_blank" style="color:red;">PINTEREST</a></li>
           
          </ul>
        </div>
        <div class="gadget">
          <h2 class="star"><span>Our Sponsors</span></h2>
          <div class="clr"></div>
          <ul class="ex_menu">
		  
            <li><a href="http://www.ril.com/" target="_blank">RELIANCE INDUSTRIES</a><br /></li>
            <li><a href="https://www.oppo.com/in/"  target="_blank">OPPO MOBILES</a><br /></li>
            <li><a href="https://www.dabur.com/in/en-us/products/real"  target="_blank">REAL JUICE</a><br /></li>
            <li><a href="http://www.radiomirchi.com/" target="_blank">RADIO MIRCHI</a><br /></li>
            
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        
        <h2><span>New for 2019 !!</span></h2>
        <p><br />
          Advanced Level Studios may now have (2) routines per division! <br>
		  Example:  Advanced Junior – (2) Small Groups, (2) Large Groups & (2) Lines</p>
      </div>
      <div class="col c3">
        <h2><span>Registration opens June 10,2019</span></h2>
        
        <p>Spots are limited and will be filled on a first-come, first served basis.
			<br>
			Routines may only qualify at National Championships if there is space available in that division.
			</p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">Copyright @2019 All Rights Reserved</p>
      <p class="rf">Design by Arushi Shukla ITD-18030</a></p>
      <div class="clr"></div>
    </div>
  </div>
</div>
</body>
</html>
